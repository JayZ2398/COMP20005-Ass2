1. Place contents of zip file (Inputs and Outputs folders, plus the two compare_ass2 files) into the same directory as your assignment c file.
2. Rename your assignment to ass2.c.
3. Run the comparison as follows depending on your computer.
4. Any differences between your file will appear side by side.
5. If you get this output, you *should* have no differences between your program's output and any of the samples.
test0 120
test0 200
test1 120
test1 200
test2 120
test2 200
END COMPARISON


Windows:
1. Open the MinGW shell, and cd to your assignment directory.
2. Type 
compare_ass2_win.txt

Mac/Dimefox/UNIX/etc:
1. Open Terminal/MinGW/any shell you like.
2. Type
./compare_ass2_unix.txt
3. If this doesn't work, type
chmod +x compare_ass2_unix.txt
then type
./compare_ass2_unix.txt